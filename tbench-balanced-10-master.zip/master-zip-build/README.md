# TBench balanced-10 — Concept-test master bundle

6 P0 models pinned to first-party, run through Terminus-2 on Harbor via
the Arena eval-orchestrate pipeline (`toloka-partners/tolokaforge-tasks`
branch `eval/tbench-balanced-10`).

## Contents

Per model (`opus_5, opus_47, gpt55, gpt56_sol, kimi_k3, gemini_31_pro`):

- `sample/<task>/<trial>/` — per-trial artefacts from the sample stage
  (11 reps × 10 tasks; Gemini ran 13 × 10 after a rate-plan sizing wave).
- `full_rest/<task>/<trial>/` — same layout, full_rest stage (5 × 10).
- Each trial dir carries `grade.yaml`, `metrics.yaml`, `trajectory.yaml`,
  `env.yaml`, `task.yaml`, `logs.yaml`, `tool_log.yaml`.
- `facts_sample.json`, `facts_full_rest.json` — per-stage aggregate.

## Interpreting the numbers

- `grade.yaml.score` = Harbor verifier `reward`, float 0-1 = fraction of
  test cases passed.
- `grade.yaml.binary_pass` = `score >= 0.5` (T-Bench community threshold,
  matches Diego's Harbor-native baseline).
- `pass@1` = mean(binary_pass) across all trials.
- Arena leaderboard score = `pass@1^5 × 100`.
- Clean-pass rate = fraction of trials with `score = 1.0`.

Aggregate (combined sample + full_rest, 160 trials each; Gemini 180):

| Model | pass@1 | pass^5×100 | clean-pass | cost |
|---|---|---|---|---|
| Opus 5 | 0.994 | 97.0 | 37.5% | $400.80 |
| Opus 4.7 | 0.975 | 88.1 | 25.0% | $214.97 |
| GPT-5.5 | 0.969 | 85.4 | 25.6% | $115.98 |
| GPT-5.6 SOL | 0.981 | 90.9 | 30.0% | $36.06 |
| Kimi K3 | 0.988 | 94.1 | 23.1% | $107.89 |
| Gemini 3.1 Pro | 0.856 | 46.0 | 16.1% | $129.10 |

**Total spend on the 6 final chains: ~$1,005.**

## Provenance

Task set: Diego's balanced-10 subset of Terminal-Bench 2.1.
Runner: harbor-runner + Terminus-2 (Harbor 0.21.0).
Provider pins: OpenRouter `provider.only + allow_fallbacks:false` per
model, first-party. Empty-assistant normalisation via
`async_pre_call_hook` in the probe-overlay LiteLLM proxy
(tolokaforge-tools PR #141).
